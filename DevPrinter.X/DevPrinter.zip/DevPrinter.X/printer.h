
#ifndef PRINTER_H
#define PRINTER_H

extern void message();

#endif