#include <xc.h>

void message() 
{
    PORTB = 0;
}